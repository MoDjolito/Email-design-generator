import { useState, useCallback } from "react";

const SECTIONS = [
  { id: "HERO", label: "Hero", icon: "⭐", desc: "Headline + subheadline + CTA" },
  { id: "PRODUCT_SECTION", label: "Produit", icon: "📦", desc: "Produit + bénéfices" },
  { id: "INFOGRAPHIC", label: "Infographie", icon: "📊", desc: "Checklist visuelle" },
  { id: "TESTIMONIALS", label: "Témoignages", icon: "💬", desc: "2–3 cartes avis" },
  { id: "COMPARISON", label: "Comparaison", icon: "⚖️", desc: "Layout côte à côte" },
  { id: "BODY_COPY", label: "Corps de texte", icon: "📝", desc: "Layout texte épuré" },
  { id: "CTA_SECTION", label: "CTA", icon: "🎯", desc: "Bloc de conversion" },
  { id: "FOOTER", label: "Footer", icon: "🔻", desc: "Clôture de marque" },
];

const STYLES = [
  "Clean & Minimaliste",
  "Luxe & Premium",
  "Playful & Coloré",
  "Dark & Sophistiqué",
  "Naturel & Organique",
  "Bold & Éditorial",
];

const CANVASES = ["600×800", "600×1000", "1200×1200", "1200×1600"];

const SECTION_BEHAVIORS = {
  HERO: "headline fort + subheadline engageant + CTA visible en haut de section. Focal point : headline ou produit héros.",
  PRODUCT_SECTION: "visuel produit dominant + liste de bénéfices clés + CTA secondaire. Mise en avant des USP.",
  INFOGRAPHIC: "checklist transformée en layout graphique structuré. Icônes, colonnes, numérotation visuelle.",
  TESTIMONIALS: "2 à 3 cartes avis distinctes avec note étoiles, citation, prénom/avatar. Disposition horizontale ou grille.",
  COMPARISON: "tableau ou layout côte à côte (Avant/Après, Nous/Eux, Avec/Sans). Contraste visuel fort.",
  BODY_COPY: "texte aéré, hiérarchie typographique claire, accent coloré sur éléments clés. Minimaliste mais premium.",
  CTA_SECTION: "bloc pleine largeur centré, headline court percutant, bouton CTA oversized, urgence ou preuve sociale.",
  FOOTER: "logo, liens discrets, disclaimer, signature de marque. Sobre et cohérent avec le reste.",
};

const DEFAULT_FORM = {
  section: "HERO",
  isContinuation: false,
  brandName: "",
  brandWebsite: "",
  brandStyle: "",
  brandStyleCustom: "",
  headline: "",
  subheadline: "",
  ctaText: "",
  ctaUrl: "",
  bodyText: "",
  additionalContent: "",
  hasAssets: false,
  assetNotes: "",
  canvas: "600×800",
  styleOverride: "",
};

/* ─── Small reusable components ─── */

function Toggle({ value, onChange, labelOn, labelOff, sublabel }) {
  return (
    <div
      style={{
        display: "flex", alignItems: "center", gap: 12,
        padding: "14px 18px", borderRadius: 12,
        border: "1.5px solid #E2E0F0", background: "#FAFAFA",
      }}
    >
      <button
        onClick={() => onChange(!value)}
        aria-pressed={value}
        style={{
          width: 44, height: 24, borderRadius: 999, border: "none",
          background: value ? "#6C47FF" : "#D5D2E8",
          position: "relative", cursor: "pointer",
          transition: "background .2s", flexShrink: 0,
        }}
      >
        <span
          style={{
            display: "block", width: 18, height: 18, borderRadius: "50%",
            background: "#fff", position: "absolute", top: 3,
            left: value ? 23 : 3, transition: "left .2s",
            boxShadow: "0 1px 4px rgba(0,0,0,.2)",
          }}
        />
      </button>
      <div>
        <div style={{ fontWeight: 600, fontSize: 14 }}>{value ? labelOn : labelOff}</div>
        {sublabel && <div style={{ fontSize: 12, color: "#888", marginTop: 2 }}>{sublabel}</div>}
      </div>
    </div>
  );
}

function Tag({ children, active, onClick }) {
  return (
    <button
      onClick={onClick}
      style={{
        padding: "6px 14px", borderRadius: "999px",
        border: active ? "2px solid #6C47FF" : "1.5px solid #E2E0F0",
        background: active ? "#F0ECFF" : "#FAFAFA",
        color: active ? "#6C47FF" : "#555",
        fontSize: "13px", fontWeight: active ? 600 : 400,
        cursor: "pointer", transition: "all .15s",
      }}
    >
      {children}
    </button>
  );
}

function FieldLabel({ children }) {
  return (
    <div style={{ fontSize: 12, color: "#aaa", marginBottom: 4 }}>{children}</div>
  );
}

function SectionLabel({ children }) {
  return (
    <label
      style={{
        display: "block", fontSize: "12px", fontWeight: 600,
        color: "#888", letterSpacing: "0.06em",
        textTransform: "uppercase", marginBottom: 6,
      }}
    >
      {children}
    </label>
  );
}

function Input({ value, onChange, placeholder, multiline, rows = 3 }) {
  const base = {
    width: "100%", boxSizing: "border-box",
    padding: "10px 14px", borderRadius: "10px",
    border: "1.5px solid #E2E0F0", background: "#FAFAFA",
    fontSize: "14px", color: "#222",
    outline: "none", resize: multiline ? "vertical" : "none",
    transition: "border .15s",
  };
  return multiline
    ? <textarea value={value} onChange={e => onChange(e.target.value)} placeholder={placeholder} rows={rows} style={base} />
    : <input value={value} onChange={e => onChange(e.target.value)} placeholder={placeholder} style={base} />;
}

/* ─── Prompt builder ─── */

function buildPrompt(f) {
  const styleDescription = f.brandStyleCustom || f.brandStyle || "[à définir]";

  const content = [
    f.headline        && `• Headline : ${f.headline}`,
    f.subheadline     && `• Subheadline : ${f.subheadline}`,
    f.ctaText         && `• CTA : "${f.ctaText}"${f.ctaUrl ? ` → ${f.ctaUrl}` : ""}`,
    f.bodyText        && `• Corps de texte : ${f.bodyText}`,
    f.additionalContent && `• Contenu additionnel : ${f.additionalContent}`,
  ].filter(Boolean).join("\n");

  const assetBlock = f.hasAssets
    ? `Des assets visuels de marque (logo, produit, visuels) sont fournis en pièce jointe. Tu DOIS les utiliser dans le design.
— Le produit doit apparaître exactement tel quel : ne pas modifier ses proportions, couleurs, forme, label ou texte.
— Tu as une liberté créative totale sur l'environnement, la mise en scène, l'éclairage et la composition autour du produit.
— Intègre le produit de façon fluide et premium dans la section.${f.assetNotes ? `\n— Notes supplémentaires : ${f.assetNotes}` : ""}`
    : `Effectue des recherches sur la marque et son identité visuelle pour inférer les assets pertinents (couleurs, typographie, ambiance).`;

  const continuationBlock = f.isContinuation
    ? `
⬇️ MODE CONTINUATION
Continue le design email depuis la section précédente, comme si tu concevais le prochain bloc directement en dessous.
— Maintiens le même design system (couleurs, typographie, espacement, style global)
— Introduis une nouvelle composition adaptée à cette section
— Évite de répéter les éléments d'en-tête (logos, backgrounds identiques, décorations déjà utilisées)
— Assure une progression visuelle naturelle vers le bas : cohérent mais évolutif, pas une duplication.`
    : "";

  return `Tu es un designer email et directeur artistique d'élite pour des marques eCommerce premium.
Ta mission : générer un mockup visuel haute-fidélité d'une section email.

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
❗ FORMAT DE SORTIE (OBLIGATOIRE)
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
Produis UNIQUEMENT le design visuel final de la section email.
NE PAS expliquer ton design.
NE PAS donner d'instructions.
NE PAS décrire ce que tu as fait.
NE PAS produire d'étapes, de bullets ou de raisonnement.
NE PAS générer de code.
Le résultat doit ressembler à :
→ Une vraie section email designée
→ Épurée, soignée, qualité production
→ Prête à être reproduite dans Figma
${continuationBlock}

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
🧩 SECTION À DESIGNER
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
Section sélectionnée : ${f.section}
Comportement attendu : ${SECTION_BEHAVIORS[f.section]}

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
📌 CONTEXTE DE MARQUE
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
Marque : ${f.brandName || "[Nom de marque]"}
${f.brandWebsite ? `Site web : ${f.brandWebsite}` : ""}
Style : ${styleDescription}

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
📌 ASSETS VISUELS
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
${assetBlock}

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
📌 CONTENU (À UTILISER TEL QUEL)
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
${content || "→ Génère un contenu cohérent avec la marque et la section."}

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
🎨 RÈGLES DE DESIGN
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
Canvas : ${f.canvas} px
Section unique (bloc modulaire uniquement)
Hiérarchie visuelle forte
Headline large et impactant
Point focal clair (produit ou headline)
CTA clairement visible
Beaucoup d'espace blanc
Layout mobile-friendly
Esthétique DTC premium (pas générique)
${f.styleOverride ? `Contrainte de style additionnelle : ${f.styleOverride}` : ""}

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
🚫 CONTRAINTES ABSOLUES
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
Pas d'explications
Pas d'instructions
Pas de wireframes
Pas de placeholders
Pas de texte "ajouter image ici"
Une seule section dans le rendu final

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
🎯 COMMANDE FINALE
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
Génère le design visuel final de la section email.
Style : hyper-réaliste, UI design premium, branding eCommerce moderne, éclairage doux, haute définition, typographie soignée.`;
}

/* ─── Main App ─── */

export default function App() {
  const [form, setForm]         = useState(DEFAULT_FORM);
  const [copied, setCopied]     = useState(false);
  const [showPrompt, setShowPrompt] = useState(false);

  const set = useCallback(
    (key) => (val) => setForm(f => ({ ...f, [key]: val })),
    []
  );

  const prompt = buildPrompt(form);
  const selectedSection = SECTIONS.find(s => s.id === form.section);

  const copyPrompt = () => {
    navigator.clipboard.writeText(prompt);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  const showSubheadline = ["HERO", "PRODUCT_SECTION", "BODY_COPY"].includes(form.section);
  const showBodyText    = ["BODY_COPY", "INFOGRAPHIC", "PRODUCT_SECTION"].includes(form.section);

  return (
    <div
      style={{
        minHeight: "100vh",
        background: "linear-gradient(135deg, #F7F5FF 0%, #FFF5FC 100%)",
        padding: "32px 16px",
      }}
    >
      <div style={{ maxWidth: 760, margin: "0 auto" }}>

        {/* ── Header ── */}
        <div style={{ textAlign: "center", marginBottom: 40 }}>
          <div
            style={{
              display: "inline-block",
              background: "linear-gradient(135deg, #6C47FF, #C850C0)",
              borderRadius: 12, padding: "8px 18px", marginBottom: 16,
            }}
          >
            <span style={{ color: "#fff", fontSize: 13, fontWeight: 600, letterSpacing: "0.08em" }}>
              EMAIL DESIGN PROMPT GENERATOR
            </span>
          </div>
          <h1
            style={{
              fontFamily: "'Syne', sans-serif",
              fontSize: "clamp(28px, 5vw, 42px)", fontWeight: 800,
              margin: "0 0 10px",
              background: "linear-gradient(135deg, #6C47FF, #C850C0)",
              WebkitBackgroundClip: "text", WebkitTextFillColor: "transparent",
            }}
          >
            Générateur de Prompts Image
          </h1>
          <p style={{ color: "#888", fontSize: 15, margin: 0 }}>
            Remplis les champs → copie le prompt optimisé → colle dans ton générateur d'images
          </p>
        </div>

        {/* ── Form card ── */}
        <div
          style={{
            background: "#fff", borderRadius: 24,
            boxShadow: "0 4px 40px rgba(108,71,255,0.08)",
            padding: "32px 28px", display: "flex", flexDirection: "column", gap: 32,
          }}
        >

          {/* 1 · Section selector */}
          <div>
            <SectionLabel>1 · Section à designer</SectionLabel>
            <div style={{ display: "flex", flexWrap: "wrap", gap: 8, marginTop: 8 }}>
              {SECTIONS.map(s => (
                <button
                  key={s.id}
                  onClick={() => set("section")(s.id)}
                  style={{
                    padding: "10px 16px", borderRadius: 12, textAlign: "left",
                    border: form.section === s.id ? "2px solid #6C47FF" : "1.5px solid #E2E0F0",
                    background: form.section === s.id ? "#F0ECFF" : "#FAFAFA",
                    color: form.section === s.id ? "#6C47FF" : "#555",
                    fontSize: "13px", fontWeight: form.section === s.id ? 700 : 400,
                    cursor: "pointer", transition: "all .15s",
                  }}
                >
                  <span style={{ marginRight: 6 }}>{s.icon}</span>{s.label}
                  <div style={{ fontSize: 11, color: form.section === s.id ? "#9B72FF" : "#aaa", marginTop: 2 }}>
                    {s.desc}
                  </div>
                </button>
              ))}
            </div>
          </div>

          {/* Continuation toggle */}
          <Toggle
            value={form.isContinuation}
            onChange={set("isContinuation")}
            labelOn="⬇️ Mode Continuation activé"
            labelOff="⬇️ Mode Continuation"
            sublabel="Active si cette section suit une section précédemment générée"
          />

          {/* 2 · Brand context */}
          <div>
            <SectionLabel>2 · Contexte de marque</SectionLabel>
            <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: 12, marginTop: 8 }}>
              <div>
                <FieldLabel>Nom de la marque</FieldLabel>
                <Input value={form.brandName} onChange={set("brandName")} placeholder="ex: Bloom Nutrition" />
              </div>
              <div>
                <FieldLabel>Site web</FieldLabel>
                <Input value={form.brandWebsite} onChange={set("brandWebsite")} placeholder="https://..." />
              </div>
            </div>
            <div style={{ marginTop: 12 }}>
              <FieldLabel>Style de marque</FieldLabel>
              <div style={{ display: "flex", flexWrap: "wrap", gap: 6, marginBottom: 10, marginTop: 6 }}>
                {STYLES.map(s => (
                  <Tag
                    key={s}
                    active={form.brandStyle === s}
                    onClick={() => set("brandStyle")(form.brandStyle === s ? "" : s)}
                  >
                    {s}
                  </Tag>
                ))}
              </div>
              <Input
                value={form.brandStyleCustom}
                onChange={set("brandStyleCustom")}
                placeholder="Ou décris librement le style... (ex: féminin, aérien, pastel avec touches de gold)"
              />
            </div>
          </div>

          {/* 3 · Content */}
          <div>
            <SectionLabel>3 · Contenu de la section</SectionLabel>
            <div style={{ display: "flex", flexDirection: "column", gap: 12, marginTop: 8 }}>
              <div>
                <FieldLabel>Headline</FieldLabel>
                <Input value={form.headline} onChange={set("headline")} placeholder="ex: Feel Good from the Inside Out" />
              </div>

              {showSubheadline && (
                <div>
                  <FieldLabel>Subheadline</FieldLabel>
                  <Input value={form.subheadline} onChange={set("subheadline")} placeholder="ex: Votre routine bien-être, réinventée." />
                </div>
              )}

              <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: 12 }}>
                <div>
                  <FieldLabel>Texte du CTA</FieldLabel>
                  <Input value={form.ctaText} onChange={set("ctaText")} placeholder="ex: Shop Now" />
                </div>
                <div>
                  <FieldLabel>URL du CTA</FieldLabel>
                  <Input value={form.ctaUrl} onChange={set("ctaUrl")} placeholder="https://..." />
                </div>
              </div>

              {showBodyText && (
                <div>
                  <FieldLabel>Corps de texte / Points clés</FieldLabel>
                  <Input
                    multiline rows={4}
                    value={form.bodyText}
                    onChange={set("bodyText")}
                    placeholder={"ex: • Sans sucre ajouté\n• Riche en probiotiques\n• Goût vanille naturel"}
                  />
                </div>
              )}

              <div>
                <FieldLabel>Contenu additionnel (optionnel)</FieldLabel>
                <Input
                  multiline rows={2}
                  value={form.additionalContent}
                  onChange={set("additionalContent")}
                  placeholder="Tout autre élément à inclure (badges, promo, preuve sociale...)"
                />
              </div>
            </div>
          </div>

          {/* 4 · Assets */}
          <div>
            <SectionLabel>4 · Assets visuels</SectionLabel>
            <div style={{ marginBottom: 10 }}>
              <Toggle
                value={form.hasAssets}
                onChange={set("hasAssets")}
                labelOn="✅ J'ai des assets à joindre (logo, produit, visuels)"
                labelOff="🔍 Pas d'assets — le générateur fera ses propres recherches"
              />
            </div>
            {form.hasAssets && (
              <Input
                multiline rows={2}
                value={form.assetNotes}
                onChange={set("assetNotes")}
                placeholder="Notes sur les assets (ex: le produit principal est un pot vert, logo blanc sur fond sombre...)"
              />
            )}
          </div>

          {/* 5 · Technical */}
          <div>
            <SectionLabel>5 · Paramètres techniques</SectionLabel>
            <div style={{ display: "flex", gap: 8, flexWrap: "wrap", marginTop: 8, marginBottom: 14 }}>
              {CANVASES.map(c => (
                <Tag key={c} active={form.canvas === c} onClick={() => set("canvas")(c)}>
                  {c} px
                </Tag>
              ))}
            </div>
            <Input
              value={form.styleOverride}
              onChange={set("styleOverride")}
              placeholder="Contrainte de style additionnelle (ex: fond sombre obligatoire, police serif uniquement...)"
            />
          </div>

          {/* Generate button */}
          <button
            onClick={() => { setShowPrompt(true); setTimeout(() => document.getElementById("prompt-output")?.scrollIntoView({ behavior: "smooth" }), 100); }}
            style={{
              width: "100%", padding: "16px", borderRadius: 14, border: "none",
              background: "linear-gradient(135deg, #6C47FF, #C850C0)",
              color: "#fff", fontFamily: "'Syne', sans-serif",
              fontSize: 16, fontWeight: 800, cursor: "pointer",
              letterSpacing: "0.03em",
              boxShadow: "0 8px 24px rgba(108,71,255,0.3)",
              transition: "transform .15s, box-shadow .15s",
            }}
            onMouseEnter={e => { e.currentTarget.style.transform = "translateY(-2px)"; e.currentTarget.style.boxShadow = "0 12px 32px rgba(108,71,255,0.4)"; }}
            onMouseLeave={e => { e.currentTarget.style.transform = ""; e.currentTarget.style.boxShadow = "0 8px 24px rgba(108,71,255,0.3)"; }}
          >
            ✨ Générer le Prompt
          </button>
        </div>

        {/* ── Prompt output ── */}
        {showPrompt && (
          <div
            id="prompt-output"
            style={{
              marginTop: 28, background: "#fff", borderRadius: 24,
              boxShadow: "0 4px 40px rgba(108,71,255,0.08)", overflow: "hidden",
            }}
          >
            <div
              style={{
                padding: "20px 28px", borderBottom: "1.5px solid #F0ECFF",
                display: "flex", justifyContent: "space-between", alignItems: "center",
              }}
            >
              <div>
                <div style={{ fontFamily: "'Syne', sans-serif", fontWeight: 800, fontSize: 17 }}>
                  Prompt généré
                </div>
                <div style={{ fontSize: 12, color: "#aaa", marginTop: 2 }}>
                  {selectedSection?.icon} {selectedSection?.label} · {form.canvas} px
                  {form.isContinuation ? " · Continuation" : ""}
                </div>
              </div>
              <button
                onClick={copyPrompt}
                style={{
                  padding: "10px 20px", borderRadius: 10, border: "none",
                  background: copied ? "#22C55E" : "#6C47FF",
                  color: "#fff", fontSize: 13, fontWeight: 700,
                  cursor: "pointer", transition: "background .2s",
                }}
              >
                {copied ? "✓ Copié !" : "📋 Copier"}
              </button>
            </div>
            <pre
              style={{
                margin: 0, padding: "24px 28px",
                fontFamily: "'Courier New', monospace",
                fontSize: 12.5, lineHeight: 1.8, color: "#333",
                whiteSpace: "pre-wrap", wordBreak: "break-word",
                background: "#FAFBFF", maxHeight: 500, overflowY: "auto",
              }}
            >
              {prompt}
            </pre>
          </div>
        )}

        <p style={{ textAlign: "center", marginTop: 24, color: "#bbb", fontSize: 12 }}>
          Optimisé pour Midjourney · DALL·E · Ideogram · Adobe Firefly
        </p>
      </div>
    </div>
  );
}
